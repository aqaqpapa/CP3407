import React, { createContext, useContext, useState, useEffect } from 'react';

const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);

  // 页面刷新时尝试从 localStorage 恢复 user 状态
  useEffect(() => {
    const savedUser = localStorage.getItem('user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
  }, []);

  // 登录时保存用户信息
  const login = (user) => {
    setUser(user);
    localStorage.setItem('user', JSON.stringify(user)); // ✅ 存入 localStorage
  };

  // 登出时清除用户状态
  const logout = () => {
    setUser(null);
    localStorage.removeItem('user'); // ✅ 清除 localStorage
  };

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
