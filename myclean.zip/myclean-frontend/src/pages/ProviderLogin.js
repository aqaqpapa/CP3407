import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

function ProviderLogin() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleLogin = async () => {
    try {
      const res = await fetch('http://localhost:3001/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          usernameOrEmail: email,
          password,
          role: 'Provider'
        }),
      });

      const data = await res.json();

      if (data.success) {
        login(data.user);
        navigate('/provider-home');
      } else {
        alert('Login failed: ' + data.message);
      }
    } catch (err) {
      alert('Network error. Please try again later.');
      console.error(err);
    }
  };

  return (
    <div className="App" style={{ padding: '20px', maxWidth: '400px', margin: 'auto' }}>
      <h2>Provider Login</h2>
      <input
        type="email"
        placeholder="Email"
        value={email}
        onChange={e => setEmail(e.target.value)}
        required
        style={{ width: '100%', padding: '8px', marginBottom: '10px' }}
      />
      <input
        type="password"
        placeholder="Password"
        value={password}
        onChange={e => setPassword(e.target.value)}
        required
        style={{ width: '100%', padding: '8px', marginBottom: '20px' }}
      />
      <button onClick={handleLogin} style={{ width: '100%', padding: '10px' }}>Login</button>
    </div>
  );
}

export default ProviderLogin;
