import React, { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';

function ProviderProfile() {
  const { user, login } = useAuth();
  const [providerInfo, setProviderInfo] = useState({
    serviceTypes: [],
    location: '',
    hourlyRate: '',
    description: '',
    available: true,
  });

  const navigate = useNavigate();

  useEffect(() => {
    if (user?.providerInfo) {
      setProviderInfo(prev => ({
        ...prev,
        ...user.providerInfo,
        serviceTypes: user.providerInfo.serviceTypes || [],
      }));
    }
  }, [user]);

  const handleSave = async () => {
    if (!user?.id) {
      alert("User ID not found.");
      return;
    }

    const updatedUser = {
      ...user,
      providerInfo
    };

    try {
      const res = await fetch(`http://localhost:3001/api/users/${user.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedUser)
      });

      if (res.ok) {
        const updatedUserFromServer = await res.json();
        login(updatedUserFromServer);
        alert("Provider profile updated successfully!");
        navigate('/provider-home');
      } else {
        alert("Failed to update provider profile.");
      }
    } catch (err) {
      console.error("Save error:", err);
      alert("Network error occurred.");
    }
  };

  return (
    <div className="App" style={{ maxWidth: '600px', margin: 'auto', padding: '20px' }}>
      <button
        onClick={() => navigate('/provider-home')}
        style={{
          marginBottom: '20px',
          backgroundColor: '#007bff',
          color: 'white',
          padding: '10px 20px',
          border: 'none',
          borderRadius: '4px'
        }}
      >
        ← Back to Home
      </button>

      <h2>Edit Provider Profile</h2>

      <label>Service Types (comma-separated)</label>
      <input
        type="text"
        value={(providerInfo.serviceTypes || []).join(', ')}
        onChange={(e) => {
          const services = e.target.value.split(',').map(s => s.trim());
          setProviderInfo(prev => ({ ...prev, serviceTypes: services }));
        }}
        style={{ width: '100%', marginBottom: '10px' }}
      />

      <label>Location</label>
      <input
        type="text"
        name="location"
        value={providerInfo.location}
        onChange={(e) => {
          const { name, value } = e.target;
          setProviderInfo(prev => ({ ...prev, [name]: value }));
        }}
        style={{ width: '100%', marginBottom: '10px' }}
      />

      <label>Hourly Rate</label>
      <input
        type="number"
        name="hourlyRate"
        value={providerInfo.hourlyRate}
        onChange={(e) => {
          const { name, value } = e.target;
          setProviderInfo(prev => ({ ...prev, [name]: value }));
        }}
        style={{ width: '100%', marginBottom: '10px' }}
      />

      <label>Description</label>
      <textarea
        name="description"
        value={providerInfo.description}
        onChange={(e) => {
          const { name, value } = e.target;
          setProviderInfo(prev => ({ ...prev, [name]: value }));
        }}
        rows="4"
        style={{ width: '100%', marginBottom: '10px' }}
      />

      <br />
      <button onClick={handleSave} style={{ marginTop: '20px', padding: '10px 20px' }}>
        Save Profile
      </button>
    </div>
  );
}

export default ProviderProfile;
