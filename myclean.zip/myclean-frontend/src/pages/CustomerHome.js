import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';


function CustomerHome() {
  const { logout, user } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <div className="App">
      <h2>Welcome, {user?.username || 'Customer'}</h2>
      <p>This is your dashboard</p>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '15px', marginTop: '20px' }}>
        <button onClick={() => navigate('/customer-order')}>Make a New Order</button> {/* 新增按钮 */}
        <button onClick={() => navigate('/search-providers')}>Search Nearby Cleaning Services</button>
        <button onClick={() => navigate('/customer-bookings')}>View My Bookings</button>
        <button onClick={() => navigate('/edit-profile')}>Edit Profile</button>
        <button onClick={handleLogout} style={{ marginTop: '30px', color: 'white', backgroundColor: '#d9534f' }}>
          Logout
        </button>
      </div>
    </div>
  );
}

export default CustomerHome;
