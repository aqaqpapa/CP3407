import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import wechatQR from './wechatpay.jpg'; 

function PaymentPage() {
  const { orderId } = useParams();
  const navigate = useNavigate();
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(false);
  const [showPaymentCode, setShowPaymentCode] = useState(false); // 控制付款码显示

  useEffect(() => {
    fetch(`http://localhost:3001/api/bookings/${orderId}`)
      .then(res => res.json())
      .then(data => setOrder(data))
      .catch(err => {
        console.error('Failed to load order:', err);
        alert('Failed to load order info.');
        navigate('/');
      });
  }, [orderId, navigate]);

  const handlePayment = async () => {
    if (!order) return;
    setLoading(true);
    try {
      const res = await fetch(`http://localhost:3001/api/bookings/${orderId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'paid' }),
      });
      if (res.ok) {
        alert('Payment successful! Your provider has been notified.');
        navigate('/');
      } else {
        alert('Payment failed. Please try again.');
      }
    } catch (err) {
      console.error('Payment error:', err);
      alert('Network error during payment.');
    } finally {
      setLoading(false);
    }
  };

  if (!order) return <div>Loading order info...</div>;

  return (
    <div style={{ maxWidth: 600, margin: 'auto', padding: 20 }}>
      <h2>Payment for Order #{order.id}</h2>
      <p><b>Provider:</b> {order.providerId}</p>
      <p><b>Date:</b> {order.date}</p>
      <p><b>Duration:</b> {order.duration} hour(s)</p>
      <p><b>Price:</b> ${order.price}</p>

      {/* Pay Now Button: 显示付款码 */}
      <button
        onClick={() => setShowPaymentCode(true)}
        disabled={loading}
        style={{
          padding: '10px 20px',
          backgroundColor: '#007bff',
          color: 'white',
          border: 'none',
          borderRadius: 4,
          marginRight: 10,
          cursor: loading ? 'not-allowed' : 'pointer',
        }}
      >
        Show Payment Code
      </button>

      {/* I have paid Button: 执行真正的支付逻辑 */}
      <button
        onClick={handlePayment}
        disabled={loading}
        style={{
          padding: '10px 20px',
          backgroundColor: '#28a745',
          color: 'white',
          border: 'none',
          borderRadius: 4,
          cursor: loading ? 'not-allowed' : 'pointer',
        }}
      >
        {loading ? 'Confirming...' : 'I have paid'}
      </button>

      {/* 显示付款码图像或内容 */}
      {showPaymentCode && (
        <div style={{ marginTop: 20, textAlign: 'center' }}>
          <h4>Scan this code to pay:</h4>
          <img
           src={wechatQR}
           alt="Payment QR Code"
           style={{ marginTop: 10, maxWidth: '100%', height: 'auto' }}
          />
        </div>
      )}
    </div>
  );
}

export default PaymentPage;
