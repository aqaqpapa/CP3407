import React, { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';

function ProviderIncomeStats() {
  const { user } = useAuth();
  const [orders, setOrders] = useState([]);
  const [view, setView] = useState('total'); // 'total' | 'today' | 'month'

  useEffect(() => {
    if (!user) return; // 🛡️ 避免 user 为空时报错

    fetch('http://localhost:3001/api/bookings')
      .then(res => res.json())
      .then(data => {
        const completedOrders = data.filter(order =>
          order.providerId === user.id && order.status === 'completed'
        );
        setOrders(completedOrders);
      });
  }, [user]);

  const getTodayDateString = () => {
    const today = new Date();
    return today.toISOString().split('T')[0];
  };

  const getMonthAgoDate = () => {
    const date = new Date();
    date.setMonth(date.getMonth() - 1);
    return date;
  };

  const calculateIncome = () => {
    const todayStr = getTodayDateString();
    const monthAgo = getMonthAgoDate();

    let filtered = orders;

    if (view === 'today') {
      filtered = orders.filter(order => order.date === todayStr);
    } else if (view === 'month') {
      filtered = orders.filter(order => new Date(order.date) >= monthAgo);
    }

    return filtered.reduce((sum, order) => sum + Number(order.price), 0);
  };

  if (!user) return <p>Loading user...</p>; // 🛡️ 防止渲染时访问 null

  return (
    <div style={{ maxWidth: 600, margin: 'auto', padding: 20 }}>
      <h2>My Income Statistics</h2>

      <div style={{ marginBottom: 20 }}>
        <button onClick={() => setView('total')} style={{ marginRight: 10 }}>
          Total Income
        </button>
        <button onClick={() => setView('today')} style={{ marginRight: 10 }}>
          Today's Income
        </button>
        <button onClick={() => setView('month')}>
          Last 30 Days
        </button>
      </div>

      <h3>
        {view === 'total' && 'Total Income:'}
        {view === 'today' && "Today's Income:"}
        {view === 'month' && 'Income in Last 30 Days:'}
        {' '}
        ${calculateIncome().toFixed(2)}
      </h3>
    </div>
  );
}

export default ProviderIncomeStats;
