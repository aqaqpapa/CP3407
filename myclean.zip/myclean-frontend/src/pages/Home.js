import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

function Home() {
  const { user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (user) {
      if (user.role === 'Customer') navigate('/customer-home');
      else if (user.role === 'Provider') navigate('/provider-home');
    }
  }, [user, navigate]);

  const handleSelect = (role) => {
    if (role === 'Customer') {
      navigate('/login-customer');
    } else if (role === 'Provider') {
      navigate('/login-provider');
    }
  };

  return (
    <div className="App">
      <h1>Welcome to MyClean</h1>
      <p>Please select your role:</p>
      <div style={{ display: 'flex', justifyContent: 'center', gap: '20px', marginTop: '20px' }}>
        <button onClick={() => handleSelect('Customer')}>I am a Customer</button>
        <button onClick={() => handleSelect('Provider')}>I am a Cleaning Service Provider</button>
        <button onClick={() => navigate('/register')}>Register</button> {/* 新增的注册按钮 */}
      </div>
    </div>
  );
}

export default Home;
