import React, { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';

function ProviderOrdersPage() {
  const { user } = useAuth();
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [rejectReasonMap, setRejectReasonMap] = useState({});
  const [rejectingOrderId, setRejectingOrderId] = useState(null);

  useEffect(() => {
    if (!user) return;
    setLoading(true);
    fetch('http://localhost:3001/api/bookings')
      .then(res => res.json())
      .then(data => {
        const myOrders = data.filter(order => order.providerId === user.id);
        setOrders(myOrders);
      })
      .catch(err => {
        console.error(err);
        alert('Failed to load orders.');
      })
      .finally(() => setLoading(false));
  }, [user]);

  const updateStatus = async (orderId, newStatus, rejectReason = '') => {
    const body = { status: newStatus };
    if (rejectReason) body.rejectReason = rejectReason;

    const res = await fetch(`http://localhost:3001/api/bookings/${orderId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });

    if (res.ok) {
      setOrders(prev =>
        prev.map(o =>
          o.id === orderId ? { ...o, status: newStatus, rejectReason: rejectReason || o.rejectReason } : o
        )
      );
      alert(`Order marked as ${newStatus}`);
      setRejectingOrderId(null);
      setRejectReasonMap(prev => ({ ...prev, [orderId]: '' }));
    } else {
      alert('Failed to update order status.');
    }
  };

  if (!user) return <p>Loading user info...</p>;
  if (loading) return <p>Loading orders...</p>;

  const pendingOrders = orders.filter(o => o.status === 'paid');
  const ongoingOrders = orders.filter(o => o.status === 'accepted');
  const finishedOrders = orders.filter(o => o.status === 'completed' || o.status === 'rejected');

  return (
    <div style={{ maxWidth: '1000px', margin: 'auto', padding: '20px', fontFamily: 'Arial, sans-serif' }}>
      <h2 style={{ color: '#333', borderBottom: '2px solid #f0f0f0', paddingBottom: '10px' }}>Order Management Dashboard</h2>

      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '20px' }}>
        <div style={styles.section}>
          <h3 style={{ color: '#2c3e50' }}>Pending Orders ({pendingOrders.length})</h3>
          {pendingOrders.length === 0 ? (
            <p style={{ color: '#7f8c8d' }}>No pending orders</p>
          ) : (
            pendingOrders.map(order => (
              <div key={order.id} style={styles.card}>
                <p><b>Customer ID:</b> {order.customerId}</p>
                <p><b>Date:</b> {order.date}</p>
                <p><b>Time:</b> {order.startTime} - {order.endTime}</p>
                <p><b>Notes:</b> {order.notes || 'N/A'}</p>
                <p><b>Status:</b> {order.status}</p>
                <div style={styles.buttonGroup}>
                  <button onClick={() => updateStatus(order.id, 'accepted')} style={styles.acceptButton}>
                    Accept
                  </button>
                  {rejectingOrderId === order.id ? (
                    <>
                      <input
                        type="text"
                        placeholder="Enter rejection reason"
                        value={rejectReasonMap[order.id] || ''}
                        onChange={e => setRejectReasonMap(prev => ({ ...prev, [order.id]: e.target.value }))}
                        style={styles.input}
                      />
                      <button
                        onClick={() => {
                          const reason = rejectReasonMap[order.id];
                          if (!reason || reason.trim() === '') {
                            alert('Please enter a rejection reason');
                            return;
                          }
                          updateStatus(order.id, 'rejected', reason);
                        }}
                        style={styles.rejectButton}
                      >
                        Confirm Reject
                      </button>
                      <button onClick={() => setRejectingOrderId(null)} style={styles.cancelButton}>
                        Cancel
                      </button>
                    </>
                  ) : (
                    <button onClick={() => setRejectingOrderId(order.id)} style={styles.rejectButton}>
                      Reject
                    </button>
                  )}
                </div>
              </div>
            ))
          )}
        </div>

        <div style={styles.section}>
          <h3 style={{ color: '#2c3e50' }}>Ongoing Orders ({ongoingOrders.length})</h3>
          {ongoingOrders.length === 0 ? (
            <p style={{ color: '#7f8c8d' }}>No ongoing orders</p>
          ) : (
            ongoingOrders.map(order => (
              <div key={order.id} style={styles.card}>
                <p><b>Customer ID:</b> {order.customerId}</p>
                <p><b>Date:</b> {order.date}</p>
                <p><b>Time:</b> {order.startTime} - {order.endTime}</p>
                <p><b>Notes:</b> {order.notes || 'N/A'}</p>
                <p><b>Status:</b> {order.status}</p>
                <button onClick={() => updateStatus(order.id, 'completed')} style={styles.completeButton}>
                  Mark as Complete
                </button>
              </div>
            ))
          )}
        </div>

        <div style={styles.section}>
          <h3 style={{ color: '#2c3e50' }}>Completed Orders ({finishedOrders.length})</h3>
          {finishedOrders.length === 0 ? (
            <p style={{ color: '#7f8c8d' }}>No completed orders</p>
          ) : (
            finishedOrders.map(order => (
              <div key={order.id} style={styles.card}>
                <p><b>Customer ID:</b> {order.customerId}</p>
                <p><b>Date:</b> {order.date}</p>
                <p><b>Time:</b> {order.startTime} - {order.endTime}</p>
                <p><b>Notes:</b> {order.notes || 'N/A'}</p>
                <p><b>Status:</b> {order.status}</p>
                {order.status === 'rejected' && order.rejectReason && (
                  <p style={{ color: '#e74c3c' }}><b>Rejection Reason:</b> {order.rejectReason}</p>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}

const styles = {
  section: {
    flex: 1,
    marginRight: '20px',
    marginBottom: '20px',
    backgroundColor: '#fff',
    borderRadius: '8px',
    boxShadow: '0 2px 10px rgba(0, 0, 0, 0.1)',
    padding: '20px',
    maxHeight: '70vh',
    overflowY: 'auto',
  },
  card: {
    border: '1px solid #e0e0e0',
    borderRadius: '6px',
    padding: '15px',
    marginBottom: '15px',
    backgroundColor: '#f9f9f9',
  },
  buttonGroup: {
    marginTop: '10px',
    display: 'flex',
    gap: '10px',
  },
  acceptButton: {
    backgroundColor: '#2ecc71',
    color: 'white',
    border: 'none',
    padding: '8px 15px',
    borderRadius: '4px',
    cursor: 'pointer',
    fontSize: '14px',
  },
  rejectButton: {
    backgroundColor: '#e74c3c',
    color: 'white',
    border: 'none',
    padding: '8px 15px',
    borderRadius: '4px',
    cursor: 'pointer',
    fontSize: '14px',
  },
  cancelButton: {
    backgroundColor: '#95a5a6',
    color: 'white',
    border: 'none',
    padding: '8px 15px',
    borderRadius: '4px',
    cursor: 'pointer',
    fontSize: '14px',
  },
  completeButton: {
    backgroundColor: '#3498db',
    color: 'white',
    border: 'none',
    padding: '8px 15px',
    borderRadius: '4px',
    cursor: 'pointer',
    fontSize: '14px',
  },
  input: {
    flex: 1,
    padding: '6px 10px',
    border: '1px solid #ccc',
    borderRadius: '4px',
    fontSize: '14px',
  },
};

export default ProviderOrdersPage;