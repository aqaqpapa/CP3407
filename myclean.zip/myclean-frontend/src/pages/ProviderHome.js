import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

function ProviderHome() {
  const navigate = useNavigate();
  const { user, login, logout } = useAuth();

  // 先用 useState 初始化，再用 useEffect 同步 user 变化
  const [isAvailable, setIsAvailable] = useState(user?.providerInfo?.available ?? true);

  useEffect(() => {
    setIsAvailable(user?.providerInfo?.available ?? true);
  }, [user]);  // user 变化时同步更新 isAvailable

  const toggleAvailability = async () => {
    if (!user?.id) {
      alert("User ID not found.");
      return;
    }

    const updatedUserPayload = {
      ...user,
      providerInfo: {
        ...user.providerInfo,
        available: !isAvailable,
      },
    };

    try {
      const res = await fetch(`http://localhost:3001/api/users/${user.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedUserPayload),
      });

      if (res.ok) {
        const updatedUserFromServer = await res.json();
        login(updatedUserFromServer); // 更新上下文 user
        // 不用手动 setIsAvailable，useEffect 会自动同步
      } else {
        alert("Failed to update availability.");
      }
    } catch (err) {
      console.error("Error updating availability:", err);
      alert("Network error.");
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <div className="App">
      <h2>Welcome, {user?.username || 'Cleaning Service Provider'}!</h2>

      <button
        onClick={toggleAvailability}
        style={{
          backgroundColor: isAvailable ? 'green' : 'gray',
          color: 'white',
          padding: '10px',
          marginTop: '15px',
        }}
      >
        {isAvailable ? '✅ Available for Work' : '❌ Currently Unavailable'}
      </button>

      <div style={{ marginTop: '20px', display: 'flex', flexDirection: 'column', gap: '15px' }}>
        <button onClick={() => navigate('/provider-bookings')}>Manage Booking Schedule</button>
        <button onClick={() => navigate('/provider-availability')}>Set Pricing & Availability</button>
        <button onClick={() => navigate('/provider-income')}>View Income Statistics</button>
        <button onClick={() => navigate('/provider-profile')}>Edit Profile</button>
        <button onClick={handleLogout}>Logout</button>
      </div>
    </div>
  );
}

export default ProviderHome;
