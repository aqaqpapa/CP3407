import React, { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Link } from 'react-router-dom';

function CustomerBookings() {
  const { user } = useAuth();
  const [bookings, setBookings] = useState([]);
  const [providers, setProviders] = useState({}); // 存储 providerId -> providerName 映射
  const [ratingMap, setRatingMap] = useState({}); // 临时存储评分值

  useEffect(() => {
    if (!user) return;

    const fetchData = async () => {
      const bookingsRes = await fetch('http://localhost:3001/api/bookings');
      const bookingsData = await bookingsRes.json();

      const myBookings = bookingsData.map(b => ({
        rating: null, // 保证有 rating 字段
        ...b
      })).filter(b => b.customerId === user.id);

      setBookings(myBookings);

      // 获取所有 provider 的名字
      const usersRes = await fetch('http://localhost:3001/api/users');
      const usersData = await usersRes.json();

      const providerNames = {};
      usersData.forEach(u => {
        providerNames[u.id] = u.name;
      });
      setProviders(providerNames);
    };

    fetchData();
  }, [user]);

  const updateRating = async (orderId, rating) => {
    const res = await fetch(`http://localhost:3001/api/bookings/${orderId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ rating }),
    });

    if (res.ok) {
      setBookings(prev =>
        prev.map(b =>
          b.id === orderId ? { ...b, rating } : b
        )
      );
      alert('Thank you for your rating!');
    } else {
      alert('Failed to submit rating.');
    }
  };

  const categorized = {
    pending: [],
    paid: [],
    ongoing: [],
    finished: [],
  };

  bookings.forEach(b => {
    if (b.status === 'pending') categorized.pending.push(b);
    else if (b.status === 'paid') categorized.paid.push(b);
    else if (b.status === 'accepted') categorized.ongoing.push(b);
    else if (b.status === 'completed' || b.status === 'rejected') categorized.finished.push(b);
  });

  const renderBooking = (b, showRating = false) => (
    <div key={b.id} style={{ border: '1px solid #ccc', marginBottom: 10, padding: 15 }}>
      <p><b>Order ID:</b> {b.id}</p>
      <p><b>Provider:</b> {providers[b.providerId] || b.providerId}</p>
      <p><b>Date:</b> {b.date}</p>
      <p><b>Time:</b> {b.startTime} - {b.endTime}</p>
      <p><b>Status:</b> {b.status}</p>

      {b.status === 'pending' && (
        <Link to={`/payment/${b.id}`}>
          <button style={{ backgroundColor: '#28a745', color: 'white' }}>
            Go to Payment
          </button>
        </Link>
      )}

      {showRating && b.status === 'completed' && b.rating == null && (
        <div>
          <label>Rate this service: </label>
          <select
            value={ratingMap[b.id] || ''}
            onChange={e =>
              setRatingMap(prev => ({ ...prev, [b.id]: parseInt(e.target.value) }))
            }
          >
            <option value="">Select rating</option>
            {[1, 2, 3, 4, 5].map(r => (
              <option key={r} value={r}>{r}</option>
            ))}
          </select>
          <button onClick={() => updateRating(b.id, ratingMap[b.id])}>Submit</button>
        </div>
      )}

      {showRating && b.status === 'completed' && b.rating != null && (
        <p><b>Your rating:</b> {b.rating}</p>
      )}
    </div>
  );

  return (
    <div style={{ maxWidth: 800, margin: 'auto', padding: 20 }}>
      <h2>Your Bookings</h2>

      <h3>🕐 Pending (Unpaid)</h3>
      {categorized.pending.length === 0 ? <p>No unpaid bookings.</p> : categorized.pending.map(b => renderBooking(b))}

      <h3>📥 Awaiting Acceptance</h3>
      {categorized.paid.length === 0 ? <p>No paid bookings waiting for acceptance.</p> : categorized.paid.map(b => renderBooking(b))}

      <h3>🚧 Ongoing</h3>
      {categorized.ongoing.length === 0 ? <p>No ongoing bookings.</p> : categorized.ongoing.map(b => renderBooking(b))}

      <h3>✅ Finished</h3>
      {categorized.finished.length === 0 ? <p>No finished bookings.</p> : categorized.finished.map(b => renderBooking(b, true))}
    </div>
  );
}

export default CustomerBookings;
