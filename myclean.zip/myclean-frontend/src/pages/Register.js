import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

function Register() {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    role: 'Customer',
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const res = await fetch('http://localhost:3001/api/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData),
    });

    const data = await res.json();
    if (data.success) {
      alert('Registration successful!');
      navigate('/');
    } else {
      alert('Registration failed: ' + data.message);
    }
  };

  return (
    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
      <div style={cardStyle}>
        <h2 style={{ textAlign: 'center' }}>Register</h2>
        <form onSubmit={handleSubmit}>
          <input
            name="username"
            placeholder="Username"
            onChange={handleChange}
            required
            style={inputStyle}
          /><br />
          <input
            name="email"
            type="email"
            placeholder="Email"
            onChange={handleChange}
            required
            style={inputStyle}
          /><br />
          <input
            name="password"
            type="password"
            placeholder="Password"
            onChange={handleChange}
            required
            style={inputStyle}
          /><br />
          <select
            name="role"
            onChange={handleChange}
            style={{ ...inputStyle, padding: '8px' }}
          >
            <option value="Customer">Customer</option>
            <option value="Provider">Cleaning Service Provider</option>
          </select><br /><br />
          <button type="submit" style={buttonStyle}>Register</button>
        </form>
        <button onClick={() => navigate('/')} style={{ ...buttonStyle, backgroundColor: '#999', marginTop: '10px' }}>
          Back to Home
        </button>
      </div>
    </div>
  );
}

// Reusable inline styles
const cardStyle = {
  border: '1px solid #ccc',
  padding: '30px',
  borderRadius: '8px',
  width: '300px',
  boxShadow: '0 0 10px rgba(0,0,0,0.1)',
};

const inputStyle = {
  width: '100%',
  padding: '10px',
  margin: '8px 0',
  boxSizing: 'border-box',
};

const buttonStyle = {
  width: '100%',
  padding: '10px',
  backgroundColor: '#007bff',
  color: 'white',
  border: 'none',
  borderRadius: '4px',
  cursor: 'pointer',
};

export default Register;
