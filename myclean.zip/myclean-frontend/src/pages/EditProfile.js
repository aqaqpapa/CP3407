import React, { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';

function CustomerEditProfile() {
  const { user } = useAuth();
  const [customerInfo, setCustomerInfo] = useState({
    location: '',
    description: '',
  });

  const navigate = useNavigate();

  // 从 user 中初始化
  useEffect(() => {
    if (user?.customerInfo) {
      setCustomerInfo({
        location: user.customerInfo.location || '',
        description: user.customerInfo.description || '',
      });
    }
  }, [user]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setCustomerInfo(prev => ({ ...prev, [name]: value }));
  };

  const handleSave = async () => {
    if (!user?.id) {
      alert("User ID not found.");
      return;
    }

    const updatedUser = {
      ...user,
      customerInfo: {
        ...user.customerInfo,
        ...customerInfo
      }
    };

    try {
      const res = await fetch(`http://localhost:3001/api/users/${user.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedUser)
      });

      if (res.ok) {
        alert("Profile updated successfully!");
        navigate('/customer-home'); // 根据你的实际路由调整
      } else {
        alert("Failed to update profile.");
      }
    } catch (err) {
      console.error("Save error:", err);
      alert("Network error occurred.");
    }
  };

  return (
    <div className="App" style={{ maxWidth: '600px', margin: 'auto', padding: '20px' }}>
      <button onClick={() => navigate('/customer-home')} style={{ marginBottom: '20px' }}>
        ← Back to Home
      </button>

      <h2>Edit Your Profile</h2>

      <label>Address</label>
      <input
        type="text"
        name="location"
        value={customerInfo.location}
        onChange={handleChange}
        style={{ width: '100%', marginBottom: '10px' }}
      />

      <label>Description</label>
      <textarea
        name="description"
        value={customerInfo.description}
        onChange={handleChange}
        rows="4"
        style={{ width: '100%', marginBottom: '10px' }}
      />

      <button onClick={handleSave} style={{ marginTop: '20px', padding: '10px 20px' }}>
        Save Profile
      </button>
    </div>
  );
}

export default CustomerEditProfile;
