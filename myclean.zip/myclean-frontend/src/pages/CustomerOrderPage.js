import React, { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';

function CustomerOrderPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [providers, setProviders] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [providerRatings, setProviderRatings] = useState({});
  const [providerComments, setProviderComments] = useState({});
  const [filter, setFilter] = useState({ sortBy: 'rating' });
  const [selectedProvider, setSelectedProvider] = useState(null);
  const [showCommentsFor, setShowCommentsFor] = useState(null);
  const [orderDetails, setOrderDetails] = useState({
    date: '',
    startTime: '',
    endTime: '',
    notes: '',
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetch('http://localhost:3001/api/users')
      .then(res => res.json())
      .then(data => {
        const filtered = data.filter(u => u.providerInfo && u.providerInfo.available);
        setProviders(filtered);
      })
      .catch(err => console.error('Failed to load providers:', err));

    fetch('http://localhost:3001/api/bookings')
      .then(res => res.json())
      .then(data => setBookings(data))
      .catch(err => console.error('Failed to load bookings:', err));
  }, []);

  useEffect(() => {
    const ratings = {};
    const comments = {};

    providers.forEach(provider => {
      const relevant = bookings.filter(b => b.providerId === provider.id && b.rating != null);
      if (relevant.length > 0) {
        const avgRating = (
          relevant.reduce((acc, cur) => acc + (cur.rating || 0), 0) / relevant.length
        ).toFixed(1);
        ratings[provider.id] = avgRating;
        comments[provider.id] = relevant.filter(b => b.comment && b.comment.trim() !== '');
      } else {
        ratings[provider.id] = null;
        comments[provider.id] = [];
      }
    });

    setProviderRatings(ratings);
    setProviderComments(comments);
  }, [bookings, providers]);

  const sortedProviders = [...providers].sort((a, b) => {
    if (filter.sortBy === 'rating') {
      return (providerRatings[b.id] || 0) - (providerRatings[a.id] || 0);
    } else if (filter.sortBy === 'hourlyRate') {
      return (a.providerInfo.hourlyRate || 0) - (b.providerInfo.hourlyRate || 0);
    }
    return 0;
  });

  const handleOrderChange = e => {
    const { name, value } = e.target;
    setOrderDetails(prev => ({ ...prev, [name]: value }));
  };

  const validateTime = (start, end) => {
    if (!start || !end) return false;
    return start < end;
  };

  const handleSubmitOrder = async () => {
    if (!user) return alert('Please login first.');
    if (!orderDetails.date) return alert('Please select a date.');
    if (!validateTime(orderDetails.startTime, orderDetails.endTime)) {
      return alert('Please select a valid time range where start time is before end time.');
    }
    if (!selectedProvider) return alert('Please select a provider.');

    setLoading(true);

    const [startHour, startMin] = orderDetails.startTime.split(':').map(Number);
    const [endHour, endMin] = orderDetails.endTime.split(':').map(Number);
    let duration = endHour + endMin / 60 - (startHour + startMin / 60);
    if (duration <= 0) duration = 1;

    const newOrder = {
      customerId: user.id,
      providerId: selectedProvider.id,
      date: orderDetails.date,
      startTime: orderDetails.startTime,
      endTime: orderDetails.endTime,
      duration,
      notes: orderDetails.notes,
      status: 'pending',
      createdAt: new Date().toISOString(),
      price: selectedProvider.providerInfo.hourlyRate * duration,
    };

    try {
      const res = await fetch('http://localhost:3001/api/bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newOrder),
      });
      if (res.ok) {
        const savedOrder = await res.json();
        alert('Order placed successfully! Redirecting to payment...');
        setSelectedProvider(null);
        setOrderDetails({ date: '', startTime: '', endTime: '', notes: '' });
        navigate(`/payment/${savedOrder.id}`);
      } else {
        alert('Failed to place the order. Please try again.');
      }
    } catch (err) {
      console.error('Order submission error:', err);
      alert('Network error occurred.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ maxWidth: 900, margin: 'auto', padding: 20 }}>
      <h2>Browse Cleaning Service Providers</h2>
      <div style={{ marginBottom: 20 }}>
        <label>Sort by: </label>
        <select
          value={filter.sortBy}
          onChange={e => setFilter({ sortBy: e.target.value })}
        >
          <option value="rating">Highest Rating</option>
          <option value="hourlyRate">Lowest Hourly Rate</option>
        </select>
      </div>

      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 15 }}>
        {sortedProviders.map(p => (
          <div key={p.id} style={{ border: '1px solid #ddd', borderRadius: 6, padding: 15, width: '280px' }}>
            <h3>{p.username}</h3>
            <p><b>Description:</b> {p.providerInfo.description || 'No description'}</p>
            <p><b>Location:</b> {p.providerInfo.location || 'No location'}</p>
            <p><b>Service types:</b> {p.providerInfo.serviceTypes.join(', ')}</p>
            <p><b>Hourly rate:</b> ${p.providerInfo.hourlyRate}/hr</p>
            <p>
              <b>Rating:</b>{' '}
              {providerRatings[p.id] ? providerRatings[p.id] + ' ★' : 'No ratings yet'}
            </p>
            <button onClick={() => setShowCommentsFor(p.id)} style={{ marginBottom: 10 }}>
              View Comments
            </button>
            <button onClick={() => setSelectedProvider(p)}>Book Now</button>
          </div>
        ))}
      </div>

      {showCommentsFor && (
        <div onClick={() => setShowCommentsFor(null)} style={modalBackdropStyle}>
          <div style={modalStyle} onClick={e => e.stopPropagation()}>
            <h3>Comments for {providers.find(u => u.id === showCommentsFor)?.username}</h3>
            {(providerComments[showCommentsFor] && providerComments[showCommentsFor].length > 0) ? (
              providerComments[showCommentsFor].map((c, idx) => (
                <div key={idx} style={{ border: '1px solid #ddd', padding: 8, marginBottom: 8 }}>
                  <p><b>Rating:</b> {c.rating} ★</p>
                  {c.comment && <p><i>{c.comment}</i></p>}
                  <p><small>{c.date}</small></p>
                </div>
              ))
            ) : (
              <p><i>No comments available.</i></p>
            )}
            <button onClick={() => setShowCommentsFor(null)}>Close</button>
          </div>
        </div>
      )}

      {selectedProvider && (
        <div style={modalBackdropStyle} onClick={() => setSelectedProvider(null)}>
          <div style={modalStyle} onClick={e => e.stopPropagation()}>
            <h3>Book {selectedProvider.username}</h3>
            <label>Booking Date</label>
            <input
              type="date"
              name="date"
              value={orderDetails.date}
              onChange={handleOrderChange}
              style={{ width: '100%', marginBottom: 10 }}
            />

            <label>Start Time</label>
            <select
              name="startTime"
              value={orderDetails.startTime}
              onChange={handleOrderChange}
              style={{ width: '100%', marginBottom: 10 }}
            >
              <option value="">-- Select Start Time --</option>
              {Array.from({ length: 14 }, (_, i) => {
                const hour = 9 + i;
                const time = `${hour.toString().padStart(2, '0')}:00`;
                return <option key={time} value={time}>{time}</option>;
              })}
            </select>

            <label>End Time</label>
            <select
              name="endTime"
              value={orderDetails.endTime}
              onChange={handleOrderChange}
              style={{ width: '100%', marginBottom: 10 }}
            >
              <option value="">-- Select End Time --</option>
              {Array.from({ length: 14 }, (_, i) => {
                const hour = 10 + i;
                const time = `${hour.toString().padStart(2, '0')}:00`;
                return <option key={time} value={time}>{time}</option>;
              })}
            </select>

            <label>Notes</label>
            <textarea
              name="notes"
              value={orderDetails.notes}
              onChange={handleOrderChange}
              style={{ width: '100%', marginBottom: 10 }}
              rows={3}
            />

            <button
              disabled={loading}
              onClick={handleSubmitOrder}
              style={{
                padding: '10px 20px',
                backgroundColor: '#007bff',
                color: 'white',
                border: 'none',
                borderRadius: 4,
                cursor: loading ? 'not-allowed' : 'pointer',
              }}
            >
              {loading ? 'Booking...' : 'Confirm Booking'}
            </button>

            <button onClick={() => setSelectedProvider(null)} style={{ marginLeft: 10 }}>
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

const modalBackdropStyle = {
  position: 'fixed',
  top: 0, left: 0, right: 0, bottom: 0,
  backgroundColor: 'rgba(0,0,0,0.4)',
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center'
};

const modalStyle = {
  backgroundColor: 'white',
  padding: 20,
  borderRadius: 8,
  minWidth: 320
};

export default CustomerOrderPage;
